#!/bin/bash
./bin/odin4

ODIN_BIN="/storage/emulated/0/Download/Flash Tool/bin/odin4"
STOCK_PATH="/storage/emulated/0/Download/Flash Tool/rom/"


echo -e "\e[32m=========================
     FLASH TOOL
=========================\e[0m"

PS3='ECOLHA UMA OPÇÃO DESSA LISTA: (1-12): '

options=("FLASHAR STOCK COMPLETA" "FLASHAR BL" "FLASHAR AP" "FLASHAR CP" "FLASHAR CSC" "FLASHAR UMS" "MOSTRAR VERSÃO" "SELECIONAR OPÇÃO NAND-ERASE" "SELECIONAR OPÇÃO PIT" "REINICIAR PARA O MODO NORMAL" "REINICIAR PARA O MODO DOWNLOAD" "SAIR")

select opt in "${options[@]}"
do
case $opt in
"FLASHAR STOCK COMPLETA") 
$ODIN_BIN -b "$STOCK_PATH/BL.tar" $ODIN_BIN -a "$STOCK_PATH/AP.tar" $ODIN_BIN -c "$STOCK_PATH/CP.tar" $ODIN_BIN  "$STOCK_PATH/CSC.tar"
;;
"SAIR")
break
;;
esac
done